
//var editor; // use a global for the submit and return data rendering in the examples
var fname;
$(document).ready(function() {
  
} );
function myGridFunc()
{
 var editor 
	 var table = document.createElement('table');
	table.setAttribute('id', 'example');
	document.body.appendChild(table);

var request = $.ajax({
		type: 'GET',
		url: 'http://localhost:3000/ResultSetOutput', 
		async: false,
		dataType: 'json',
		success: function (data) {	
		var myJSON = JSON.stringify(data); 
		console.log("RESPONSE data"+myJSON);	
		
		//	var myObj = JSON.parse(myJSON);
		
		//Add row identifier attribute "DT_RowId" in json output.		
		var keys = [];
		var len = data.length;
	
		for(i=0;i<len;i++){
		data[i].DT_RowId = "row_"+(i+1);
		
		}
				
		//add the hidden columns in hiddenCols Array example:- hiddenCols = ["a","b","c"]
	var hiddenCols = ["DT_RowId"];
	var isHidden = false;
		//get Keys of json data
	for(var k in data[0]){
		var isHidden = false;
		for(m=0;m<hiddenCols.length;m++){
		if(hiddenCols[m]==k){
		isHidden = true;
		break ; 
		}
		
		}

		if(!isHidden){
			keys.push(k);
			}
			
		}
		

//build grid columns based on keys
		
		var objArray = [];
		var objEditArray = [];
		var checkBoxCol = {
                data: null,
                defaultContent: '',
                className: 'select-checkbox',
                orderable: false
            } ;
			
		objArray.push(checkBoxCol) ;
		
		
		for(i=0;i<keys.length;i++){
		var jobj ;
		var eobj ;
		
		jobj = {"title":keys[i],"data":keys[i]}	;
		objArray.push(jobj) ;
		
		eobj={"label":keys[i],"name":keys[i]} ;
		objEditArray.push(eobj) ;
		
		
		
		}

		
	//dataTables editor code
		editor = new $.fn.dataTable.Editor( {
         
        table: "#example",
        fields: objEditArray
    } );
 

 
 
    // Activate an inline edit on click of a table cell
    $('#example').on( 'click', 'tbody td:not(:first-child)', function (e) {
        editor.inline( this );
    } );
  
    editor.on( 'open', function ( e, type ) {
	
      // $("#DTE_Field_id").prop("readonly", true);
    } );
    $('#example').DataTable( {
        dom: "Bfrtip",
        data : data,
        order: [[ 1, 'asc' ]],
        columns: objArray,
		"columnDefs": [
            {
                "targets": [ 1],
                "visible": false
            }
        ],
        select: {
            style:    'os',
            selector: 'td:first-child'
        },
        buttons: [
            { extend: "create", editor: editor,
			formButtons: [
                {
                    label: 'Create',
                    fn: function () { 
									var newObj = {"id":$("#DTE_Field_id").val(),
												  "First_Name":$("#DTE_Field_First_Name").val(),
												  "Last_Name":$("#DTE_Field_Last_Name").val(),
												   "Email":$("#DTE_Field_Email").val(),
												   "Start_Date":$("#DTE_Field_Start_Date").val(),
												  }
						
								var request = $.ajax({
												type: 'POST',
												url: 'http://localhost:3000/ResultSetOutput', 
												async: false,
												dataType: 'json',
												data:newObj,
												success: function (data) {	
												
												},
												error: function (data,err) {
												console.log("err",err,unescape(data.name));
												}
						});

							
						this.close();
						location.reload();
					}
                }
               
            ]
			
			},
            { extend: "edit",   editor: editor,
			formButtons: [
                {
                    label: 'Update',
                    fn: function () { 
					var id = $("#DTE_Field_id").val();
					var url = 'http://localhost:3000/ResultSetOutput/'+id;
									var newObj = {"id":$("#DTE_Field_id").val(),
												  "First_Name":$("#DTE_Field_First_Name").val(),
												  "Last_Name":$("#DTE_Field_Last_Name").val(),
												   "Email":$("#DTE_Field_Email").val(),
												   "Start_Date":$("#DTE_Field_Start_Date").val(),
												  }
						
								var request = $.ajax({
												type: 'PUT',
												url: url, 
												async: false,
												dataType: 'json',
												data:newObj,
												success: function (data) {	
												
												},
												error: function (data,err) {
												console.log("err",err,unescape(data.name));
												}
						});

							
						this.close();
						location.reload(); 
					}
                }
               
            ]
			
			
			
			},
            { extend: "remove", editor: editor,
			formButtons: [
                {
                    label: 'Delete',
                    fn: function () { 
						var table =		$('#example').DataTable( );
						var tdval = table.rows( { selected: true } ).data()
					  	var id = tdval[0].id ;	
						fname = tdval[0].First_Name
						
					var url = 'http://localhost:3000/ResultSetOutput/'+id;
									
								var request = $.ajax({
												type: 'DELETE',
												url: url, 
												async: false,
												dataType: 'json',
												
												success: function (data) {	
												
												},
												error: function (data,err) {
												console.log("err",err,unescape(data.name));
												}
						});

							
						this.close();
						location.reload();
					}
                }
               
            ]

			}
        ]
    } );
		},
		error: function (data,err) {
		console.log("err",err,unescape(data.name));
		}
		});	


}
function myGridFunc2()
{
var editor 
	 var table = document.createElement('table');
	table.setAttribute('id', 'example1');
	document.body.appendChild(table);

var table =		$('#example').DataTable( );
						var tdval = table.rows( { selected: true } ).data()
					  	//var id = tdval[0].id ;	
						fname = tdval[0].First_Name
alert(fname)
var url = 'http://localhost:4000/Address?First_Name='+fname ;
var request = $.ajax({
		type: 'GET',
		url: url , 
		async: false,
		dataType: 'json',
		success: function (data) {
		console.log(JSON.stringify(data))
		//***************************************************************************************
		var myJSON = JSON.stringify(data); 
		console.log("RESPONSE data"+myJSON);
		
				//	var myObj = JSON.parse(myJSON);
		
		//Add row identifier attribute "DT_RowId" in json output.		
		var keys = [];
		var len = data.length;
	
		for(i=0;i<len;i++){
		data[i].DT_RowId = "row_"+(i+1);
		
		}
				
		//add the hidden columns in hiddenCols Array example:- hiddenCols = ["a","b","c"]
	var hiddenCols = ["DT_RowId"];
	var isHidden = false;
		//get Keys of json data
	for(var k in data[0]){
		var isHidden = false;
		for(m=0;m<hiddenCols.length;m++){
		if(hiddenCols[m]==k){
		isHidden = true;
		break ; 
		}
		
		}

		if(!isHidden){
			keys.push(k);
			}
			
		}
		

//build grid columns based on keys
		
		var objArray = [];
		var objEditArray = [];
		var checkBoxCol = {
                data: null,
                defaultContent: '',
                className: 'select-checkbox',
                orderable: false
            } ;
			
		objArray.push(checkBoxCol) ;
		
		
		for(i=0;i<keys.length;i++){
		var jobj ;
		var eobj ;
		
		jobj = {"title":keys[i],"data":keys[i]}	;
		objArray.push(jobj) ;
		
		eobj={"label":keys[i],"name":keys[i]} ;
		objEditArray.push(eobj) ;
		
		
		
		}

		
	//dataTables editor code
		editor = new $.fn.dataTable.Editor( {
         
        table: "#example1",
        fields: objEditArray
    } );
 

 
 
    // Activate an inline edit on click of a table cell
    $('#example1').on( 'click', 'tbody td:not(:first-child)', function (e) {
        editor.inline( this );
    } );
  
    editor.on( 'open', function ( e, type ) {
	
      // $("#DTE_Field_id").prop("readonly", true);
    } );
	
    $('#example1').DataTable( {
        dom: "Bfrtip",
        data : data,
        order: [[ 1, 'asc' ]],
        columns: objArray,
		"columnDefs": [
            {
                "targets": [ 1],
                "visible": false
            }
        ],
        select: {
            style:    'os',
            selector: 'td:first-child'
        },
        buttons: [
           
            { extend: "edit",   editor: editor,
			formButtons: [
                {
                    label: 'Update',
                    fn: function () { 
					var id= $("#DTE_Field_id").val();
					var url = 'http://localhost:4000/Address/'+id;
					alert(url)
									var newObj = {
													
												  "First_Name":$("#DTE_Field_First_Name").val(),
												  "City":$("#DTE_Field_City").val(),
												   "State":$("#DTE_Field_State").val(),
												   "Country":$("#DTE_Field_Country").val(),
												   "Zip-Code":$("#DTE_Field_Zip-Code").val()
												  }
						
								var request = $.ajax({
												type: 'PUT',
												url: url, 
												async: false,
												dataType: 'json',
												data:newObj,
												success: function (data) {	
												
												},
												error: function (data,err) {
												console.log("err",err,unescape(data.name));
												}
						});

							
						this.close();
						location.reload(); 
					}
                }
               
            ]
			
			
			
			},
            { extend: "remove", editor: editor,
			formButtons: [
                {
                    label: 'Delete',
                    fn: function () { 
						var table =		$('#example1').DataTable( );
						var tdval = table.rows( { selected: true } ).data()
					  	var id = tdval[0].id ;	
						//fname = tdval[0].First_Name
						
					var url = 'http://localhost:4000/Address/'+id;
									
								var request = $.ajax({
												type: 'DELETE',
												url: url, 
												async: false,
												dataType: 'json',
												
												success: function (data) {	
												
												},
												error: function (data,err) {
												console.log("err",err,unescape(data.name));
												}
						});

							
						this.close();
						location.reload();
					}
                }
               
            ]

			}
        ]
    } );
		//***************************************************************************************
		},
		error: function (data,err) {
		console.log("err",err,unescape(data.name));
		}
		});
		
}

 
